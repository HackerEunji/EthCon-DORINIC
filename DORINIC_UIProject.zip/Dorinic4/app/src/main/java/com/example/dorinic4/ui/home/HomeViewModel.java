package com.example.dorinic4.ui.home;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class HomeViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public HomeViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("도리를 위해 \n니모닉을 \n0개 \n저장했습니다.\n");

    }

    public LiveData<String> getText() {
        return mText;
    }
}